def get_mood_lesson(m):
    if m == "happy":
        return "😊 Let's learn some fun English words today!"
    if m == "sad":
        return "💙 It's okay. Let's learn something easy."
    return "👍 Small step, but still learning!"
