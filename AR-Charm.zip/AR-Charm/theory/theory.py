def get_theory():
    return "📖 Theory:\nIn Present Simple we add -s with he/she/it."
