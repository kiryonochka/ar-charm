import sqlite3
import time

db = "data.db"

def init_db():
    con = sqlite3.connect(db)
    c = con.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS requests (uid INTEGER, txt TEXT, ts INTEGER)")
    con.commit()
    con.close()

def save_request(uid, txt):
    con = sqlite3.connect(db)
    c = con.cursor()
    c.execute("INSERT INTO requests VALUES (?, ?, ?)", (uid, txt, int(time.time())))
    con.commit()
    con.close()
