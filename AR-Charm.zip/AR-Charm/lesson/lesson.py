def get_lesson():
    # TODO: рандомная тема из списка
    return "📘 Lesson of the day:\nPresent Simple — I play, you read."
