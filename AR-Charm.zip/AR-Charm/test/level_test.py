def start_test():
    return "🧪 Level test: Choose correct answer: She ___ tea (drink/drinks)"
