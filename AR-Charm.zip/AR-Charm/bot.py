from telegram import ReplyKeyboardMarkup, Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
from config import TOKEN
from database import init_db, save_request
from mood.mood_lesson import get_mood_lesson
from lesson.lesson import get_lesson
from tasks.tasks import get_tasks
from theory.theory import get_theory
from test.level_test import start_test

# кнопки меню
btns = [
    ["📘 Урок дня", "✏️ Задачи"],
    ["📖 Теория", "😊 Урок под настроение"],
    ["🧪 Мини-тест"]
]

async def start(u: Update, ctx: ContextTypes.DEFAULT_TYPE):
    init_db()
    await u.message.reply_text(
        "Привет! Я бот для изучения английского 🇬🇧",
        reply_markup=ReplyKeyboardMarkup(btns, resize_keyboard=True)
    )

async def on_msg(u: Update, ctx: ContextTypes.DEFAULT_TYPE):
    msg = u.message.text
    save_request(u.message.from_user.id, msg)

    if "Урок дня" in msg:
        res = get_lesson()
    elif "Задачи" in msg:
        res = get_tasks()
    elif "Теория" in msg:
        res = get_theory()
    elif "настроение" in msg:
        res = get_mood_lesson("happy")  # TODO: дать выбор настроения
    elif "тест" in msg:
        res = start_test()
    else:
        res = "Выбери кнопку 👇"

    await u.message.reply_text(res)


app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_msg))
app.run_polling()
