def get_tasks():
    return "✏️ Tasks:\n1) Translate: I like apples.\n2) Choose: He ___ football (play/plays)"
